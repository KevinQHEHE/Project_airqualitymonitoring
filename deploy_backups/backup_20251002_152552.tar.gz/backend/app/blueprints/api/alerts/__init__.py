"""Alerts blueprint initialization."""
