"""Auth blueprint initialization."""
