// Create collection: users

db.createCollection("users", {
  "validator": {
    "$jsonSchema": {
      "bsonType": "object",
      "required": [
        "username",
        "email",
        "passwordHash",
        "role"
      ],
      "properties": {
        "username": {
          "bsonType": "string"
        },
        "email": {
          "bsonType": "string"
        },
        "passwordHash": {
          "bsonType": "string"
        },
        "role": {
          "enum": [
            "user",
            "admin"
          ]
        },
        "status": {
          "enum": [
            "active",
            "inactive"
          ]
        },
        "preferences": {
          "bsonType": "object",
          "properties": {
            "language": {
              "bsonType": "string"
            },
            "theme": {
              "enum": [
                "light",
                "dark"
              ]
            },
            "favoriteStations": {
              "bsonType": "array",
              "items": {
                "bsonType": "int"
              }
            },
            "defaultStation": {
              "bsonType": "int"
            },
            "notifications": {
              "bsonType": "object"
            }
          }
        },
        "createdAt": {
          "bsonType": "date"
        },
        "updatedAt": {
          "bsonType": "date"
        }
      }
    }
  }
});

// Create indexes for users
db.users.createIndex({"email": 1}, { "unique": true });
db.users.createIndex({"username": 1}, { "unique": true });
