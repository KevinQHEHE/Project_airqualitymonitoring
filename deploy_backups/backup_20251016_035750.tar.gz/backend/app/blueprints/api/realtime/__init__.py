"""Realtime blueprint initialization."""
