"""API blueprints package for organizing Flask API routes."""
