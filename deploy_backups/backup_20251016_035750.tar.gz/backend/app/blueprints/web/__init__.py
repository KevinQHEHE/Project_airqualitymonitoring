"""Web blueprint initialization."""
