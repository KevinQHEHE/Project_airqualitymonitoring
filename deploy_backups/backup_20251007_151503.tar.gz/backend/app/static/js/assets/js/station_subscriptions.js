// station_subscriptions.js - minimal functionality to render subscriptions
// Expected backend endpoints:
// GET  /api/subscriptions -> { subscriptions: [...] }
// POST /api/subscriptions/unsubscribe { station_id }
// POST /api/subscriptions/subscribe { station_id, ... }
// PUT  /api/subscriptions/{id} { alert_enabled, threshold, nickname }

let currentView = 'grid';
let subscriptionsInitialized = false;
// Cache fetched subscriptions so we can re-render grid/list views without
// refetching from the server on every view switch or optimistic UI update.
let cachedSubscriptions = [];

// Initialize subscriptions only when explicitly called
function initializeSubscriptions() {
	if (subscriptionsInitialized) {
		refreshSubscriptions();
		return;
	}
	subscriptionsInitialized = true;
	setView(currentView);
	refreshSubscriptions();
}

// Only auto-initialize if we're on a standalone subscriptions page
document.addEventListener('DOMContentLoaded', () => {
	// Check if we're on the integrated dashboard or standalone subscriptions page
	const isDashboardIntegrated = document.getElementById('dashboard-content') !== null;
	const isStandaloneSubscriptions = document.querySelector('.subscriptions-container') !== null && !isDashboardIntegrated;
	
	if (isStandaloneSubscriptions) {
		initializeSubscriptions();
	}
});

function setView(view) {
	currentView = view;
	document.getElementById('gridViewBtn').classList.toggle('active', view === 'grid');
	document.getElementById('listViewBtn').classList.toggle('active', view === 'list');
	document.getElementById('subscriptionsGrid').style.display = view === 'grid' ? 'grid' : 'none';
	document.getElementById('subscriptionsList').style.display = view === 'list' ? 'block' : 'none';

	// Re-render from cache so toggles/thresholds reflect the current state
	// immediately when switching between grid and list without a full reload.
	if (cachedSubscriptions && cachedSubscriptions.length) {
		renderSubscriptions(cachedSubscriptions);
	}
}

async function refreshSubscriptions() {
	const token = localStorage.getItem('access_token');
	const containerGrid = document.getElementById('subscriptionsGrid');
	const containerList = document.getElementById('subscriptionsList');
	const emptyState = document.getElementById('emptyState');
	const countEl = document.getElementById('subscriptionCount');

	containerGrid.innerHTML = '';
	containerList.innerHTML = '';
	
	console.log('Token:', token ? 'Present' : 'Missing');

	try {
		const resp = await fetch('/api/subscriptions', { headers: { 'Authorization': `Bearer ${token}` } });
		console.log('API Response status:', resp.status);
		
		if (!resp.ok) {
			const errorText = await resp.text();
			console.error('API Error:', errorText);
			throw new Error('Failed to fetch subscriptions');
		}
		
	const data = await resp.json();
		console.log('API Data received:', data);
		
	const subs = data.subscriptions || [];
	// update cache
	cachedSubscriptions = subs;
		console.log('Subscriptions count:', subs.length);
		console.log('First subscription:', subs[0]);
		
		// Debug AQI values
		subs.forEach((sub, i) => {
			console.log(`=== SUBSCRIPTION ${i} DEBUG ===`);
			console.log(`Station ID: ${sub.station_id}`);
			console.log(`Station Name: ${sub.station_name}`);
			console.log(`Current AQI: ${sub.current_aqi} (type: ${typeof sub.current_aqi})`);
			console.log(`Last Updated: ${sub.last_updated}`);
			console.log(`Full object:`, sub);
		});

		// render from cache
		renderSubscriptions(subs);

	} catch (e) {
		console.error('Error loading subscriptions', e);
		emptyState.style.display = 'block';
	}
}

function createStationCard(s) {
	console.log('Creating station card for:', s.station_name || s.nickname, 'AQI:', s.current_aqi);
	
	// Handle null/undefined AQI
	const displayAQI = s.current_aqi != null ? s.current_aqi : 'N/A';
	const aqiValue = s.current_aqi != null ? s.current_aqi : 0; // For color calculation
	
	// Grid card
	const gridCard = document.createElement('div');
	gridCard.className = 'station-card new';
	gridCard.style.setProperty('--station-color', getAQIColor(aqiValue));
	// Compute a stable display name: prefer nickname, then station_name, then location,
	// and finally a clear fallback including the station id to avoid ambiguous labels.
	const displayName = s.nickname || s.station_name || s.location || (`Station ${s.station_id}`);
	gridCard.innerHTML = `
		<div class="station-header">
			<div class="station-name-container">
				<h4 class="station-name">${escapeHtml(displayName)}</h4>
				<div class="station-id">${escapeHtml(String(s.station_id))}</div>
				<div class="added-date">${formatTimestamp(s.created_at) || ''}</div>
			</div>
			<div class="aqi-display">
				<div class="aqi-circle ${getAQIClass(aqiValue)}">
					<div class="aqi-value">${displayAQI}</div>
					<div class="aqi-label">AQI</div>
				</div>
				<div class="aqi-details">
					<div class="aqi-description">Last: ${formatTimestamp(s.last_updated) || 'No data'}</div>
					<div class="added-date">Added: ${formatTimestamp(s.created_at) || ''}</div>
				</div>
			</div>
			<div class="alert-controls">
				<div class="alert-toggle">
					<div class="alert-label" data-subscription-id="${s.id}">Alerts
						<small data-subscription-id="${s.id}" style="font-weight:400;color:#7f8c8d;">${s.alert_enabled ? 'On' : 'Off'}</small>
					</div>
					<button data-subscription-id="${s.id}" class="toggle-switch ${s.alert_enabled ? 'active' : ''}" onclick="toggleAlert(this, '${s.station_id}', '${s.id}')"></button>
				</div>
				<div class="threshold-control">
					<div class="threshold-label">
						<div>Threshold</div>
							<div class="threshold-value" data-subscription-id="${s.id}">${s.threshold ?? s.current_aqi ?? 100}</div>
					</div>
						<input data-subscription-id="${s.id}" type="range" min="0" max="500" value="${s.threshold ?? s.current_aqi ?? 100}" class="threshold-slider" oninput="onThresholdInput(event, '${s.station_id}', '${s.id}')" onchange="onThresholdCommit(event, '${s.station_id}', '${s.id}')">
				</div>
			</div>
			<div class="station-controls">
				<button class="unsubscribe-btn" onclick="confirmUnsubscribe('${s.station_id}')">Unsubscribe</button>
			</div>
		</div>
	`;

	// List item (with AQI display)
	const listItem = document.createElement('div');
	listItem.className = 'station-card list-item';
	const listDisplayName = s.nickname || s.station_name || s.location || (`Station ${s.station_id}`);
	listItem.innerHTML = `
		<div class="station-header">
			<div class="station-name-container">
				<h4 class="station-name">${escapeHtml(listDisplayName)}</h4>
				<div class="station-id">${escapeHtml(String(s.station_id))}</div>
				<div class="added-date">${formatTimestamp(s.created_at) || ''}</div>
			</div>

			<div class="controls-column">
				<div class="aqi-compact-mobile">
					<div class="aqi-circle-small ${getAQIClass(aqiValue)}">
						<span class="aqi-value-small">${displayAQI}</span>
					</div>
				</div>
				<div class="control-stack">
					<div class="alert-toggle-small">
						<span class="alert-label-small" data-subscription-id="${s.id}">Alerts ${s.alert_enabled ? 'On' : 'Off'}</span>
						<button data-subscription-id="${s.id}" class="toggle-switch-small ${s.alert_enabled ? 'active' : ''}" onclick="toggleAlert(this, '${s.station_id}', '${s.id}')"></button>
					</div>
					<div class="threshold-inline">
						<span class="threshold-label-small">Threshold: <span class="threshold-value" data-subscription-id="${s.id}">${s.threshold ?? s.current_aqi ?? 100}</span></span>
					</div>
					<div class="unsubscribe-wrap">
						<button class="unsubscribe-btn" onclick="confirmUnsubscribe('${s.station_id}')">Unsubscribe</button>
					</div>
				</div>
			</div>
		</div>
	`;

	return { grid: gridCard, list: listItem };
}

// Render subscriptions into both grid and list containers from an array of
// subscription objects. This allows us to update UI based on cached data when
// switching views or applying optimistic updates without refetching.
function renderSubscriptions(subs) {
	const containerGrid = document.getElementById('subscriptionsGrid');
	const containerList = document.getElementById('subscriptionsList');
	const emptyState = document.getElementById('emptyState');

	containerGrid.innerHTML = '';
	containerList.innerHTML = '';

	const countEl = document.getElementById('subscriptionCount');
	countEl.textContent = String(subs.length || 0);

	if (!subs.length) {
		emptyState.style.display = 'block';
		return;
	} else {
		emptyState.style.display = 'none';
	}

	subs.forEach((s, index) => {
		try {
			const card = createStationCard(s);
			containerGrid.appendChild(card.grid);
			containerList.appendChild(card.list);
		} catch (e) {
			console.error('Error rendering subscription item', e, s);
		}
	});
}

function getAQIColor(aqi) {
	if (aqi <= 50) return '#00e676';
	if (aqi <= 100) return '#ffd54f';
	if (aqi <= 150) return '#ff9800';
	if (aqi <= 200) return '#f44336';
	if (aqi <= 300) return '#9c27b0';
	return '#8d6e63';
}

function getAQIClass(aqi) {
	if (aqi <= 50) return 'aqi-good';
	if (aqi <= 100) return 'aqi-moderate';
	if (aqi <= 150) return 'aqi-unhealthy-sensitive';
	if (aqi <= 200) return 'aqi-unhealthy';
	if (aqi <= 300) return 'aqi-very-unhealthy';
	return 'aqi-hazardous';
}

function formatTimestamp(timestamp) {
	if (!timestamp) return '';
	try {
		const date = new Date(timestamp);
		return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
	} catch (e) {
		return timestamp;
	}
}

function escapeHtml(unsafe) {
	return String(unsafe)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;')
		.replace(/'/g, '&#039;');
}

function confirmUnsubscribe(stationId) {
	if (!confirm('Are you sure you want to unsubscribe from this station?')) return;
	unsubscribeStation(stationId);
}

async function unsubscribeStation(stationId) {
	const token = localStorage.getItem('access_token');
	try {
		const resp = await fetch('/api/subscriptions/unsubscribe', {
			method: 'POST',
			headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
			body: JSON.stringify({ station_id: stationId })
		});
		if (!resp.ok) throw new Error('Unsubscribe failed');
		refreshSubscriptions();
		alert('Unsubscribed');
	} catch (e) {
		console.error(e);
		alert('Failed to unsubscribe');
	}
}

async function toggleAlert(el, stationId, subscriptionId) {
	// Optimistic UI: toggle visual state immediately
	try {
		const token = localStorage.getItem('access_token');
		if (!token) {
			alert('You must be logged in to change alert settings');
			return;
		}

		// Determine current state from button class
		const button = el;
		const isActive = button.classList.contains('active');
		const newState = !isActive;

		// Update UI immediately (only update explicit alert label elements)
		button.classList.toggle('active', newState);

		// Optimistically update our in-memory cache so that switching between
		// grid/list views reflects the new state immediately without reload.
		let reverted = false;
		let prevCacheState = null;
		if (cachedSubscriptions && cachedSubscriptions.length) {
			const idx = cachedSubscriptions.findIndex(c => String(c.id) === String(subscriptionId));
			if (idx !== -1) {
				prevCacheState = { ...cachedSubscriptions[idx] };
				cachedSubscriptions[idx] = { ...cachedSubscriptions[idx], alert_enabled: newState };
				// Re-render from cache
				renderSubscriptions(cachedSubscriptions);
			}
		}

		// Only target the alert label elements so we don't accidentally overwrite other
		// parts of the card that may also carry `data-subscription-id` (e.g. sliders,
		// threshold displays, or other injected content). This avoids replacing the
		// station name with a generic fallback like "Station 1583".
		const labelSelector = [
			`.alert-label small[data-subscription-id="${subscriptionId}"]`,
			`.alert-label-small[data-subscription-id="${subscriptionId}"]`
		].join(',');
		const labelEls = Array.from(document.querySelectorAll(labelSelector));
		const prevLabelStates = labelEls.map(l => ({ el: l, text: l.textContent }));
		labelEls.forEach(l => {
			// These elements are the explicit text holders for the alert state.
			l.textContent = newState ? 'On' : 'Off';
		});

		// Send update to server
		const resp = await fetch(`/api/subscriptions/${subscriptionId}`, {
			method: 'PUT',
			headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
			body: JSON.stringify({ alert_enabled: newState })
		});

		if (!resp.ok) {
			const txt = await resp.text().catch(() => 'no body');
			// revert optimistic cache update if present
			if (prevCacheState && cachedSubscriptions) {
				const idx2 = cachedSubscriptions.findIndex(c => String(c.id) === String(subscriptionId));
				if (idx2 !== -1) cachedSubscriptions[idx2] = prevCacheState;
				renderSubscriptions(cachedSubscriptions);
				reverted = true;
			}
			throw new Error(`Server responded ${resp.status}: ${txt}`);
		}

		console.log(`Alert ${newState ? 'enabled' : 'disabled'} for subscription ${subscriptionId}`);
	} catch (err) {
		console.error('Failed to toggle alert:', err);
		// Revert optimistic UI
		if (el && el.classList) el.classList.toggle('active');
		// Revert cache update if it was applied
		try {
			if (typeof prevCacheState !== 'undefined' && prevCacheState && cachedSubscriptions) {
				const idx3 = cachedSubscriptions.findIndex(c => String(c.id) === String(prevCacheState.id));
				if (idx3 !== -1) cachedSubscriptions[idx3] = prevCacheState;
				renderSubscriptions(cachedSubscriptions);
			}

			if (typeof prevLabelStates !== 'undefined' && Array.isArray(prevLabelStates)) {
				prevLabelStates.forEach(item => {
					try { item.el.textContent = item.text; } catch (e) { /* ignore */ }
				});
			}
		} catch (e) {
			// ignore revert errors
		}
		alert('Failed to toggle alert: ' + (err.message || err));
	}
}

function onThresholdInput(e, stationId, subscriptionId) {
	// Live preview while dragging: update visible displays and other sliders only.
	const val = e.target.value;
	const subId = subscriptionId || e.target.getAttribute('data-subscription-id');
	if (subId) {
		const displays = document.querySelectorAll(`.threshold-value[data-subscription-id="${subId}"]`);
		displays.forEach(d => d.textContent = val);

		const sliders = document.querySelectorAll(`input[type=range][data-subscription-id="${subId}"]`);
		sliders.forEach(s => {
			if (s !== e.target) s.value = val;
		});
	} else {
		let display = e.target.parentElement?.querySelector('.threshold-value') || null;
		if (!display) {
			const header = e.target.closest('.station-header');
			display = header?.querySelector('.threshold-value') || null;
		}
		if (display) display.textContent = val;
	}
}

function onThresholdCommit(e, stationId, subscriptionId) {
	// Commit handler: user finished dragging (onchange). Apply optimistic cache
	// update, render both views, and send the debounced server update.
	const val = e.target.value;
	console.log(`Threshold commit to ${val} for station ${stationId} (subscriptionId=${subscriptionId})`);

	window.thresholdUpdateTimeouts = window.thresholdUpdateTimeouts || {};
	const key = subscriptionId || e.target.getAttribute('data-subscription-id') || stationId;
	clearTimeout(window.thresholdUpdateTimeouts[key]);

	// Save previous cache value so we can revert on failure
	window.thresholdPrevCache = window.thresholdPrevCache || {};
	if (cachedSubscriptions && cachedSubscriptions.length) {
		const idx = cachedSubscriptions.findIndex(c => String(c.id) === String(key) || String(c.station_id) === String(stationId));
		if (idx !== -1) {
			window.thresholdPrevCache[key] = { ...cachedSubscriptions[idx] };
			cachedSubscriptions[idx] = { ...cachedSubscriptions[idx], threshold: parseInt(val) };
			renderSubscriptions(cachedSubscriptions);
		}
	}

	window.thresholdUpdateTimeouts[key] = setTimeout(async () => {
		try {
			await updateThreshold(stationId, parseInt(val), key);
			if (window.thresholdPrevCache && window.thresholdPrevCache[key]) delete window.thresholdPrevCache[key];
		} catch (err) {
			console.error('Threshold commit failed, reverting UI/cache', err);
			if (window.thresholdPrevCache && window.thresholdPrevCache[key] && cachedSubscriptions && cachedSubscriptions.length) {
				const idx2 = cachedSubscriptions.findIndex(c => String(c.id) === String(key) || String(c.station_id) === String(stationId));
				if (idx2 !== -1) {
					cachedSubscriptions[idx2] = window.thresholdPrevCache[key];
					renderSubscriptions(cachedSubscriptions);
				}
			}
			alert('Failed to update threshold: ' + (err.message || err));
		}
	}, 300); // shorter debounce for commit
}

async function updateThreshold(stationId, threshold, subscriptionId) {
	const token = localStorage.getItem('access_token');
	console.log(`updateThreshold called: station=${stationId}, threshold=${threshold}, subscriptionId=${subscriptionId}`);

	if (!token) {
		console.error('No access token found; user may be logged out');
		alert('You must be logged in to update thresholds');
		return;
	}

	try {
		let subId = subscriptionId;

		// If subscriptionId not provided, try to find it from the DOM element data attribute
		if (!subId) {
			console.log('subscriptionId not provided; attempting to find from DOM or API');
			// Try to find slider with stationId
			const slider = document.querySelector(`input[type=range][data-subscription-id]`);
			if (slider) subId = slider.getAttribute('data-subscription-id');
		}

		// As a last resort, fetch subscriptions
		if (!subId) {
			const resp = await fetch('/api/subscriptions', { 
				headers: { 'Authorization': `Bearer ${token}` } 
			});
			if (!resp.ok) {
				const txt = await resp.text().catch(() => 'no body');
				throw new Error(`Failed to fetch subscriptions: ${resp.status} ${txt}`);
			}
			const data = await resp.json();
			const subscription = data.subscriptions?.find(s => String(s.station_id) === String(stationId));
			if (!subscription) throw new Error('Subscription not found for station');
			subId = subscription.id;
		}

		console.log(`Using subscriptionId=${subId} to update threshold`);

		const updateResp = await fetch(`/api/subscriptions/${subId}`, {
			method: 'PUT',
			headers: { 
				'Content-Type': 'application/json', 
				'Authorization': `Bearer ${token}` 
			},
			body: JSON.stringify({ threshold: threshold })
		});

		console.log(`PUT response status: ${updateResp.status}`);

		if (!updateResp.ok) {
			const errorData = await updateResp.text().catch(() => 'no body');
			console.error('Threshold update failed:', updateResp.status, errorData);
			throw new Error(`Failed to update threshold: ${updateResp.status}`);
		}

		const responseData = await updateResp.json().catch(() => ({}));
		console.log('Threshold update response:', responseData);
		console.log(`✅ Threshold updated to ${threshold} for station ${stationId} (subscription ${subId})`);

		// If server returned the updated subscription, update our cache
		try {
			if (responseData && responseData.subscription && cachedSubscriptions && cachedSubscriptions.length) {
				const updated = responseData.subscription;
				const idx = cachedSubscriptions.findIndex(c => String(c.id) === String(updated.id) || String(c.station_id) === String(updated.station_id));
				if (idx !== -1) {
					cachedSubscriptions[idx] = { ...cachedSubscriptions[idx], ...updated };
					renderSubscriptions(cachedSubscriptions);
				}
			}
		} catch (e) {
			console.warn('Failed to merge server subscription into cache', e);
		}

	} catch (e) {
		console.error('Update threshold error:', e);
		// Provide a slightly more helpful alert message
		alert('Failed to update threshold: ' + (e.message || e));
	}
}

