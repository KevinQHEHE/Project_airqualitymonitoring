"""Stations blueprint initialization."""
