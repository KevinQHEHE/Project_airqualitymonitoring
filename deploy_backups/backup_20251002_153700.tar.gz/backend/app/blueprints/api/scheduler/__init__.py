"""Scheduler API blueprint initialization."""
from .routes import scheduler_bp

__all__ = ['scheduler_bp']
