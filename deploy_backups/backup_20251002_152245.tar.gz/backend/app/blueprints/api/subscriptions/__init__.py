"""Subscriptions package initialization."""

from .routes import subscriptions_bp

__all__ = ['subscriptions_bp']