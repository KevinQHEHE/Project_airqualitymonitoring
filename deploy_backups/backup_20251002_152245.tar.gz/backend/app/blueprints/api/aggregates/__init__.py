"""Aggregates blueprint initialization."""
