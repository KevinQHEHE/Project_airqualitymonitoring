"""Air quality API: latest measurements per station.

Provides an endpoint to return the most recent measurement per station
with common pollutant fields and AQI. Supports filtering by `station_id`
and `limit` query parameter.

Design notes:
- Uses a MongoDB aggregation pipeline to pick the latest reading per station
- Projects a stable set of pollutant fields (additive; missing fields may be null)
- Returns JSON with list of station measurements
"""
from __future__ import annotations

from flask import Blueprint, request, jsonify, current_app
import logging
from typing import List, Dict, Any, Optional
from datetime import datetime, timezone, timedelta

from backend.app.db import get_db, DatabaseError
from pymongo import MongoClient
from pymongo.read_preferences import ReadPreference

logger = logging.getLogger(__name__)

air_quality_bp = Blueprint('air_quality', __name__)


def _is_signed_int(s: str) -> bool:
    """Return True if string s can be parsed as an integer (handles leading +/-, None safe)."""
    try:
        if s is None:
            return False
        int(s)
        return True
    except Exception:
        return False


def _timestamp_to_vn_iso(val):
    """Convert a datetime or ISO string to Vietnam timezone (+07:00) ISO string.

    If val is a datetime, assume UTC when naive. If val is a string and ISO-parsable,
    parse and convert; otherwise return the original value.
    """
    if val is None:
        return None
    try:
        if isinstance(val, datetime):
            dt = val
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            vn = dt.astimezone(timezone(timedelta(hours=7)))
            return vn.isoformat()

        if isinstance(val, str):
            s = val
            # handle trailing Z
            if s.endswith('Z'):
                s = s[:-1] + '+00:00'
            try:
                dt = datetime.fromisoformat(s)
            except Exception:
                return val
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=timezone.utc)
            vn = dt.astimezone(timezone(timedelta(hours=7)))
            return vn.isoformat()
    except Exception:
        return val
    return val


def build_latest_per_station_pipeline(station_id: Optional[str], limit: int) -> List[Dict[str, Any]]:
    """Build aggregation pipeline to return latest measurement per station.

    Args:
        station_id: optional station_id to filter results
        limit: maximum number of stations to return

    Returns:
        Aggregation pipeline list
    """
    match_stage = None
    # Support matching either the stored `station_id` (legacy) or `meta.station_idx` (numeric)
    def _is_signed_int(s: str) -> bool:
        try:
            if s is None:
                return False
            int(s)
            return True
        except Exception:
            return False

    if station_id:
        # If station_id can be parsed as an integer (including negative values),
        # include a numeric meta.station_idx match as well. Use int() parsing so
        # negative indices like "-469825" are handled correctly.
        if _is_signed_int(station_id):
            match_stage = {'$or': [
                {'station_id': station_id},
                {'meta.station_idx': int(station_id)}
            ]}
        else:
            match_stage = {'station_id': station_id}

    # Pollutant fields we want to include. Keep this list additive.
    pollutant_fields = [
        'pm25', 'pm10', 'o3', 'no2', 'so2', 'co', 'bc', 'nh3',
        # Include environmental fields for UI (temperature & humidity)
        't', 'h'
    ]

    # Build extraction expressions for pollutants. Many documents store pollutant
    # values under `iaqi.<pollutant>.v` (from WAQI). Fall back to top-level fields
    # if present.
    pollutant_projection = {}
    for f in pollutant_fields:
        pollutant_projection[f] = {'$first': {'$ifNull': [f'$iaqi.{f}.v', f'${f}', None]}}

    pipeline: List[Dict[str, Any]] = []
    if match_stage:
        pipeline.append({'$match': match_stage})

    # Sort by timestamp descending so $first in grouping is the latest. Documents
    # may store time in `ts` (datetime) or `time.iso` (string). Prefer `ts`.
    pipeline.append({'$sort': {'ts': -1, 'time.iso': -1, 'timestamp': -1}})

    # Group by station_id and take the first (latest) document per station
    # Build group projection: pick fields from either meta.* or top-level fields.
    project_fields = {
        'station_id': {'$first': {'$ifNull': ['$meta.station_idx', '$station_id', None]}},
        'timestamp': {'$first': {'$ifNull': ['$ts', '$time.iso', '$timestamp', None]}},
        'aqi': {'$first': {'$ifNull': ['$aqi', None]}},
        'location': {'$first': {'$ifNull': ['$location', '$meta.location', None]}},
        'station_name': {'$first': {'$ifNull': ['$station_name', '$meta.name', None]}},
    }
    # include pollutants (already prepared as $first expressions)
    for k, expr in pollutant_projection.items():
        project_fields[k] = expr

    pipeline.append({
        '$group': {
            # Group by meta.station_idx when available, otherwise station_id.
            '_id': {'$ifNull': ['$meta.station_idx', '$station_id']},
            **project_fields
        }
    })

    # Optional lookup to enrich station_name and location from `waqi_stations` collection
    # `meta.station_idx` references `waqi_stations._id` per db schema.
    pipeline.append({
        '$lookup': {
            'from': 'waqi_stations',
            'localField': '_id',
            'foreignField': '_id',
            'as': 'station_doc'
        }
    })

    # Unwind station_doc if present (preserveEmpty to keep readings without station metadata)
    pipeline.append({'$unwind': {'path': '$station_doc', 'preserveNullAndEmptyArrays': True}})

    # Project final shape and remove _id
    final_projection = {
        '_id': 0,
        'station_id': 1,
        # station_name: fallback order: grouped station_name, waqi_stations.city.name
        'station_name': { '$ifNull': ['$station_name', '$station_doc.city.name'] },
        'timestamp': 1,
        'aqi': 1,
        # location: fallback order: grouped location, waqi_stations.city.geo
        'location': { '$ifNull': ['$location', '$station_doc.city.geo'] },
    }
    for f in pollutant_fields:
        final_projection[f] = 1

    pipeline.append({'$project': final_projection})

    # Sort by aqi desc then timestamp desc to give deterministic ordering
    pipeline.append({'$sort': {'aqi': -1, 'timestamp': -1}})

    if limit and limit > 0:
        pipeline.append({'$limit': limit})

    return pipeline


@air_quality_bp.route('/latest', methods=['GET'])
def get_latest_measurements():
    """Return the latest measurement per station.

    Query parameters:
      - station_id: optional, filter to a single station
      - limit: optional, number of stations to return (default 100, max 500)

    Returns:
        JSON list of latest measurements per station
    """
    try:
        station_id = request.args.get('station_id')
        try:
            limit = int(request.args.get('limit', 100))
        except ValueError:
            return jsonify({'error': 'limit must be an integer'}), 400

        if limit <= 0:
            return jsonify({'error': 'limit must be greater than 0'}), 400
        if limit > 500:
            return jsonify({'error': 'limit cannot exceed 500'}), 400

        try:
            db = get_db()
            pipeline = build_latest_per_station_pipeline(station_id, limit)
            logger.debug(f"Aggregation pipeline: {pipeline}")

            cursor = db.waqi_station_readings.aggregate(pipeline, allowDiskUse=False)
            results = list(cursor)
        except DatabaseError as e:
            # First attempt: try to read from secondaries (read-only) if primary missing
            try:
                mongo_uri = current_app.config.get('MONGO_URI')
                mongo_db_name = current_app.config.get('MONGO_DB')
                if mongo_uri and mongo_db_name:
                    tmp_client = MongoClient(mongo_uri, serverSelectionTimeoutMS=3000, socketTimeoutMS=5000, read_preference=ReadPreference.SECONDARY_PREFERRED)
                    try:
                        tmp_db = tmp_client[mongo_db_name]
                        cursor = tmp_db.waqi_station_readings.aggregate(pipeline, allowDiskUse=False)
                        results = list(cursor)
                        logger.warning("Read from secondary succeeded for latest (SecondaryPreferred) after primary error: %s", e)
                    finally:
                        try:
                            tmp_client.close()
                        except Exception:
                            pass
                    # If we got results, continue to normal response flow
                    if results:
                        for doc in results:
                            if 'timestamp' in doc:
                                doc['timestamp'] = _timestamp_to_vn_iso(doc.get('timestamp'))
                        return jsonify({'measurements': results}), 200
            except Exception:
                # ignore secondary read errors and fall back to cache
                pass

            # Second attempt: return a cached response if available to tolerate transient DB failures
            try:
                cache_coll = get_db().api_response_cache
                cache_key = f"latest:{station_id or 'all'}:{limit}"
                cached = cache_coll.find_one({'_id': cache_key})
                if cached and 'response' in cached:
                    logger.warning(f"Database error in get_latest_measurements, returning cached response: {e}")
                    cached_resp = cached['response']
                    # Ensure timestamps are normalized
                    for doc in cached_resp.get('measurements', []):
                        if 'timestamp' in doc:
                            doc['timestamp'] = _timestamp_to_vn_iso(doc.get('timestamp'))
                    return jsonify(cached_resp), 200
            except Exception:
                # ignore cache read errors
                pass

            logger.error(f"get_latest_measurements DB unavailable: {e}")
            return jsonify({'error': 'Database unavailable'}), 503

        # Ensure timestamps are converted to Vietnam local time ISO strings
        for doc in results:
            if 'timestamp' in doc:
                doc['timestamp'] = _timestamp_to_vn_iso(doc.get('timestamp'))

        return jsonify({'measurements': results}), 200

    except Exception as e:
        logger.error(f"get_latest_measurements error: {e}")
        return jsonify({'error': 'Internal server error'}), 500


@air_quality_bp.route('/history', methods=['GET'])
def get_history():
    """Return AQI and pollutant measurements for the last N hours for a station.

    Query params:
      - station_id: required
      - hours: optional integer, default 12, max 72

    Returns JSON: { 'station_id': <id>, 'measurements': [ { timestamp, aqi, pm25, pm10, o3, no2, so2, co, pb }, ... ] }
    """
    try:
        station_id = request.args.get('station_id')
        if not station_id:
            return jsonify({'error': 'station_id is required'}), 400

        # parse hours
        try:
            hours = int(request.args.get('hours', 12))
        except ValueError:
            return jsonify({'error': 'hours must be an integer'}), 400

        if hours <= 0:
            return jsonify({'error': 'hours must be greater than 0'}), 400
        if hours > 72:
            return jsonify({'error': 'hours cannot exceed 72'}), 400

        from datetime import datetime, timedelta

        now = datetime.utcnow()
        start_ts = now - timedelta(hours=hours)

        # Build aggregation pipeline: filter by station and timestamp >= start_ts, project required fields, sort ascending
        # Support station_id numeric vs string similar to latest pipeline
        match_stage = None
        if _is_signed_int(station_id):
            match_stage = {'$or': [ {'station_id': station_id}, {'meta.station_idx': int(station_id)} ]}
        else:
            match_stage = {'station_id': station_id}

        # Timestamp fields in documents may be `ts` (datetime) or `time.iso`/`timestamp` (string). We'll match against `ts` when available.
        pipeline = [
            {'$match': match_stage},
            # Match by time: include docs where ts >= start_ts OR time.iso >= start_iso OR timestamp >= start_iso
            {'$match': {
                '$or': [
                    {'ts': {'$gte': start_ts}},
                    {'time.iso': {'$gte': start_ts.isoformat()}},
                    {'timestamp': {'$gte': start_ts.isoformat()}},
                ]
            }},
            # Project only the fields we need
            {'$project': {
                '_id': 0,
                'station_id': {'$ifNull': ['$meta.station_idx', '$station_id']},
                'timestamp': {'$ifNull': ['$ts', '$time.iso', '$timestamp']},
                'aqi': {'$ifNull': ['$aqi', None]},
                'pm25': {'$ifNull': ['$iaqi.pm25.v', '$pm25']},
                'pm10': {'$ifNull': ['$iaqi.pm10.v', '$pm10']},
                'o3': {'$ifNull': ['$iaqi.o3.v', '$o3']},
                'no2': {'$ifNull': ['$iaqi.no2.v', '$no2']},
                'so2': {'$ifNull': ['$iaqi.so2.v', '$so2']},
                'co': {'$ifNull': ['$iaqi.co.v', '$co']},
                'pb': {'$ifNull': ['$iaqi.pb.v', '$pb']},
                't': {'$ifNull': ['$iaqi.t.v', '$t']},
                'h': {'$ifNull': ['$iaqi.h.v', '$h']},
            }},
            # Sort chronologically (oldest first)
            {'$sort': {'timestamp': 1, 'ts': 1, 'time.iso': 1}},
        ]

        try:
            db = get_db()
            logger.debug(f"History pipeline: {pipeline}")

            cursor = db.waqi_station_readings.aggregate(pipeline, allowDiskUse=False)
            results = list(cursor)
        except DatabaseError as e:
            # Try reading from secondaries first (read-only) to tolerate primary outage
            try:
                mongo_uri = current_app.config.get('MONGO_URI')
                mongo_db_name = current_app.config.get('MONGO_DB')
                if mongo_uri and mongo_db_name:
                    tmp_client = MongoClient(mongo_uri, serverSelectionTimeoutMS=3000, socketTimeoutMS=5000, read_preference=ReadPreference.SECONDARY_PREFERRED)
                    try:
                        tmp_db = tmp_client[mongo_db_name]
                        cursor = tmp_db.waqi_station_readings.aggregate(pipeline, allowDiskUse=False)
                        results = list(cursor)
                        logger.warning("Read from secondary succeeded for history (SecondaryPreferred) after primary error: %s", e)
                    finally:
                        try:
                            tmp_client.close()
                        except Exception:
                            pass
                    if results:
                        for doc in results:
                            if 'timestamp' in doc and doc['timestamp'] is not None:
                                doc['timestamp'] = _timestamp_to_vn_iso(doc.get('timestamp'))
                        return jsonify({'station_id': station_id, 'measurements': results}), 200
            except Exception:
                pass

            # Fallback to cache for history queries (best-effort)
            try:
                cache_coll = get_db().api_response_cache
                cache_key = f"history:{station_id}:{hours}"
                cached = cache_coll.find_one({'_id': cache_key})
                if cached and 'response' in cached:
                    logger.warning(f"Database error in get_history, returning cached response: {e}")
                    return jsonify(cached['response']), 200
            except Exception:
                pass
            logger.error(f"get_history DB unavailable: {e}")
            return jsonify({'error': 'Database unavailable'}), 503

        # Convert timestamps to Vietnam local time ISO strings
        for doc in results:
            if 'timestamp' in doc and doc['timestamp'] is not None:
                doc['timestamp'] = _timestamp_to_vn_iso(doc.get('timestamp'))

        return jsonify({'station_id': station_id, 'measurements': results}), 200

    except Exception as e:
        logger.error(f"get_history error: {e}")
        return jsonify({'error': 'Internal server error'}), 500
