"""Forecasts blueprint initialization."""
