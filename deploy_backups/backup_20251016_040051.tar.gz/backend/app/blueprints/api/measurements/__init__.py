"""Measurements blueprint initialization."""
